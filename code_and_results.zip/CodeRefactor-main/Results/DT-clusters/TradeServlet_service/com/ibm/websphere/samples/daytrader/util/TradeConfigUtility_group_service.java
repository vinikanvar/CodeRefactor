package com.ibm.websphere.samples.daytrader.util;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Random;

 class TradeConfigUtility_group_service 
 { 
 
public static boolean rndBoolean() {
    return randomNumberGenerator.nextBoolean();
}
} 
