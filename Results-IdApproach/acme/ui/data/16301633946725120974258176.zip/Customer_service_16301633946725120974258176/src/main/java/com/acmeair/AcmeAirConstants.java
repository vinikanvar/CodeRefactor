package com.acmeair;

public interface AcmeAirConstants {

    public int id = 0;

    public static AcmeAirConstants getObject(int id) {
        return null;
    }
}

