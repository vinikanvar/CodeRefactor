/*
 * Copyright (c) 2012, Mayocat <hello@mayocat.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
package org.mayocat.shop.marketplace.store.jdbi;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.mayocat.model.Entity;
import org.mayocat.shop.catalog.model.Product;
import org.mayocat.shop.catalog.store.jdbi.mapper.ProductMapper;
import org.skife.jdbi.v2.StatementContext;
import com.ibm.research.cma.api.MicroserviceApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * @version $Id: c8490a07441648529d61911c9bbd01eefb84f506 $
 */
public class ProductAndTenantMapper extends AbstractEntityAndTenantMapper {

    public Product extractEntity(int index, ResultSet result, StatementContext ctx) throws SQLException {
        return (Product) null;
    }

    public int id = 0;

    public static ProductAndTenantMapper getObject(int id) {
        ProductAndTenantMapper obj = (ProductAndTenantMapper) new Object();
        obj.id = id;
        return obj;
    }
}

